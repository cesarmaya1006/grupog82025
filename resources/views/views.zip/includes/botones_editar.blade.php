<div class="row">
    <div class="col-lg-3"></div>
    <div class="col-lg-2"><button type="submit" class="btn btn-sm btn-success" style="min-width: 100px;">Actualizar</button></div>
    <div class="col-lg-1"></div>
</div>
