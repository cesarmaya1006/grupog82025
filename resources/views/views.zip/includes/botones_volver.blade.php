<div class="row">
    <div class="col-lg-3"></div>
    <div class="col-lg-2">
        <a href="{{ route($pagVolver)}}" class="form-control btn btn-sm btn-success mt-2" style="min-width: 100px; max-height: 30px">Volver</a>
    </div>
    <div class="col-lg-1"></div>
</div>
