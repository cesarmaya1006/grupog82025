<div class="row">
    <div class="col-lg-9">
        <input type="file" name="documento" class="form-control" accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required/>
    </div>
    <div class="col-lg-3">
        <button type="submit" class="btn btn-sm btn-success mt-2" style="min-width: 100px;">A&ntilde;adir a galer&iacute;a</button>
    </div>
</div>
